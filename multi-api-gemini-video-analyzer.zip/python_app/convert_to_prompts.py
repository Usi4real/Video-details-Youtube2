import os
import sys
import json
import argparse
from datetime import datetime
from typing import Optional, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from python_app.gemini_client import MultiKeyGeminiClient

CONVERSION_PROMPT = """You are an expert prompt engineer for AI character consistency (Standard Image-to-Video mode).

You will receive a detailed scene-by-scene video analysis. Convert EACH segment into TWO prompts:
1. An IMAGE prompt (still frame description)
2. A VIDEO prompt (motion/animation description)

CRITICAL: Image and video prompts MUST be 1:1 matched — EXACTLY the same count. If there are 10 segments, output 10 image prompts AND 10 video prompts.

RULES:
- Each prompt (image or video) MUST be under 900 characters.
- Number each prompt explicitly.
- STYLE IS MANDATORY: Start every prompt (image AND video) with the visual style from the analysis (e.g., "Pixar-style 3D animation," or "Realistic live-action,").
- IMAGE prompts: [style], character appearance (gender, age, skin tone, hair, clothing), pose, expression, setting, lighting, camera angle.
- VIDEO prompts: [style], character movement, camera motion, expression changes, audio cues.

DIALOGUE IS MANDATORY IN VIDEO PROMPTS (DO NOT SKIP):
- If the video analysis contains ANY dialogue, voiceover, or narration for a segment, the VIDEO prompt MUST include it.
- State WHICH character speaks (by physical description), the EXACT words (in quotes), the language, and the tone.
- Example: 'The girl with red hair says in English: "Come here!" in a cheerful tone'
- ALL dialogue MUST be in the SAME language as detected in the video analysis. NEVER translate to English unless the video is in English.
- Skipping dialogue that exists in the analysis is a CRITICAL ERROR.
- However, if a segment has NO dialogue in the analysis, do NOT invent or add any dialogue. Only include dialogue when it actually exists in the video.

- Plain text only. No markdown. No introductions or commentary.

OUTPUT FORMAT:

=== IMAGE PROMPTS ===

Image Prompt 1:
[still frame for segment 1 — under 900 chars]

Image Prompt 2:
[still frame for segment 2 — under 900 chars]

Image Prompt 3:
[still frame for segment 3 — under 900 chars]

(continue for ALL segments)

=== VIDEO PROMPTS ===

Video Prompt 1:
[motion for segment 1 — under 900 chars]

Video Prompt 2:
[motion for segment 2 — under 900 chars]

Video Prompt 3:
[motion for segment 3 — under 900 chars]

(continue for ALL segments — SAME count as image prompts)
"""

class PromptConverter:
    def __init__(self, api_keys: List[str]):
        self.client = MultiKeyGeminiClient(api_keys)

    def convert(self, analysis_text: str) -> str:
        full_input = f"{analysis_text}\n\n{CONVERSION_PROMPT}"
        result = self.client.generate_content("analysis_text_input", full_input)
        if result is None:
            return "Error: No result returned from Gemini for prompt conversion."
        return result


def main():
    parser = argparse.ArgumentParser(description="Convert video analysis into image/video prompts using Gemini")
    parser.add_argument("--analysis-file", type=str, default=None, help="File containing analysis text")
    parser.add_argument("--analysis-text", type=str, default=None, help="Direct analysis text")
    parser.add_argument("--api-keys", type=str, required=True, help="Comma-separated API keys")
    parser.add_argument("--output-file", type=str, default="converted_prompts.json")
    args = parser.parse_args()

    api_keys = [k.strip() for k in args.api_keys.split(",") if k.strip()]
    if not api_keys:
        print("Error: At least one API key is required.")
        sys.exit(1)

    analysis_text = ""
    if args.analysis_text:
        analysis_text = args.analysis_text
    elif args.analysis_file and os.path.isfile(args.analysis_file):
        with open(args.analysis_file, "r", encoding="utf-8") as f:
            analysis_text = f.read()
    else:
        print("Error: Either --analysis-file or --analysis-text must be provided.")
        sys.exit(1)

    converter = PromptConverter(api_keys)
    try:
        result = converter.convert(analysis_text)
    except Exception as e:
        result = f"Error during conversion: {str(e)}"

    output = {
        "status": "success" if not result.startswith("Error") else "error",
        "converted_at": datetime.utcnow().isoformat() + "Z",
        "result": result,
    }

    with open(args.output_file, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0 if output.get("status") == "success" else 1

if __name__ == "__main__":
    sys.exit(main())
