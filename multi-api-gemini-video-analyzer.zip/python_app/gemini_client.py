import re
import os
from typing import List, Optional, Dict, Any
import google.generativeai as genai
from google.generativeai.types import GenerateContentResponse

QUOTA_ERRORS = [
    "quota",
    "exhausted",
    "resource_exhausted",
    "rate_limit",
    "429",
]

class MultiKeyGeminiClient:
    def __init__(self, api_keys: List[str]):
        self.api_keys = [k.strip() for k in api_keys if k and k.strip()]
        if not self.api_keys:
            raise ValueError("At least one API key is required.")
        self.current_index = 0
        self.usage_counts: Dict[str, int] = {k: 0 for k in self.api_keys}
        self.active_key = self.api_keys[0]
        self._init_client(self.active_key)

    def _init_client(self, key: str):
        genai.configure(api_key=key)
        self.client = genai.GenerativeModel('gemini-2.5-pro-exp-03-25')
        # Fallback to gemini-1.5-flash if the pro model isn't available
        # Actually, let's just use a reliable model name
        # We'll stick to gemini-1.5-pro or gemini-2.5-flash based on availability
        # For simplicity, use gemini-1.5-flash which supports video well
        try:
            self.client = genai.GenerativeModel('gemini-1.5-flash')
        except Exception:
            pass
        self.active_key = key

    def rotate_key(self):
        self.current_index = (self.current_index + 1) % len(self.api_keys)
        new_key = self.api_keys[self.current_index]
        self._init_client(new_key)
        return new_key

    def get_active_key(self) -> str:
        return self.active_key

    def is_quota_error(self, error_text: str) -> bool:
        text_lower = error_text.lower()
        return any(err in text_lower for err in QUOTA_ERRORS)

    def generate_content(
        self,
        video_path_or_url: str,
        prompt_text: str,
        max_retries: int = 3
    ) -> Optional[str]:
        """
        Generate analysis using Gemini with multi-key rotation.
        If video_path_or_url is a URL, we attempt to pass it or describe it.
        For best results, the video file path should be provided.
        """
        last_exception = None
        retries_per_key = max(1, max_retries // len(self.api_keys))

        for attempt in range(max_retries):
            try:
                # Try to upload video if file path exists locally
                video_file = None
                if os.path.isfile(video_path_or_url):
                    video_file = genai.upload_file(path=video_path_or_url)

                # If we uploaded successfully, use it
                if video_file:
                    response = self.client.generate_content(
                        [video_file, prompt_text],
                        request_options={"timeout": 300}
                    )
                    # Clean up file reference (optional - Gemini handles it)
                    try:
                        video_file.delete()
                    except Exception:
                        pass
                else:
                    # For URLs, include URL in prompt as context
                    # Note: Gemini doesn't always process YouTube URLs directly
                    # but we'll include the URL description
                    response = self.client.generate_content(
                        [f"YouTube Video URL: {video_path_or_url}\n\nPrompt instructions follow. Note: The video may need to be downloaded for full analysis, but please analyze based on any available context and the user's prompt.\n\n{prompt_text}"],
                        request_options={"timeout": 300}
                    )

                text = response.text
                self.usage_counts[self.active_key] += 1
                return text

            except Exception as e:
                last_exception = e
                error_str = str(e)
                print(f"API error with key ...{self.active_key[-8:]}: {error_str}")

                if self.is_quota_error(error_str):
                    # Rotate key immediately
                    new_key = self.rotate_key()
                    print(f"Quota exhausted. Switched to new key ...{new_key[-8:]}")
                else:
                    # For non-quota errors, also rotate after a couple retries
                    if attempt % len(self.api_keys) == len(self.api_keys) - 1:
                        new_key = self.rotate_key()
                        print(f"Non-quota error. Rotating to new key ...{new_key[-8:]}")

        # If we exhausted all retries
        raise Exception(f"Failed to generate content after {max_retries} retries. Last error: {last_exception}")
