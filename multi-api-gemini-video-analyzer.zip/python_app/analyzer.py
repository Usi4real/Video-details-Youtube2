import os
import sys
import json
import argparse
from datetime import datetime
from typing import Optional, List

# Ensure python_app is in the path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from python_app.gemini_client import MultiKeyGeminiClient

# Default analysis prompt based on user specification
DEFAULT_PROMPT = """You are an expert video analyst. Watch the following video with EXTREME attention to detail and produce a comprehensive, scene-by-scene analysis. Link 

BEFORE listing segments, state the OVERALL VISUAL STYLE of the video at the very top:

=== VISUAL STYLE ===
Identify the EXACT rendering/animation style. Choose the closest match:
- Pixar-style 3D animation (smooth, stylized, rounded characters)
- Disney-style 3D animation
- Realistic 3D (photorealistic CG, Unreal Engine look)
- Semi-realistic 3D (stylized but detailed)
- 2D hand-drawn animation (traditional cel animation)
- 2D digital animation (flat, vector-based, motion graphics)
- Anime style (Japanese animation aesthetic)
- Live-action realistic (real people, real camera)
- Live-action stylized (color graded, cinematic filters)
- Mixed media (combination of styles)
- Claymation / Stop-motion
- Other (describe precisely)

Also note: texture quality, color palette style (vibrant/muted/pastel/neon), rendering detail level, and any distinctive visual characteristics.

=== LANGUAGE ===
Identify the PRIMARY LANGUAGE spoken in the video. Examples: Hindi, English, Urdu, Arabic, Spanish, Punjabi, Tamil, etc.
If multiple languages are used, state the dominant one and list secondary languages.
ALL dialogues in the generated prompts MUST be written in this detected language.

Then break the video into ~8-second segments. For EACH segment, describe in full detail:

CHARACTERS:
- Gender, approximate age, ethnicity/skin tone, body build
- Hair: color, length, style
- Facial features, facial hair, expression, emotion
- EXACT clothing: color, material, style, accessories, jewelry, shoes
- If multiple characters, describe EACH one distinctly

ACTIONS:
- What each character is doing physically
- Movements, gestures, interactions with objects or other characters
- Body pose, hand positions, gaze direction
- Speed and direction of movement

DIALOGUE & SPEECH (THIS IS MANDATORY — DO NOT SKIP):
⚠️ If ANY character speaks, narrates, or there is ANY voiceover in this segment, you MUST transcribe it.
- Identify WHICH CHARACTER is speaking by their physical description (e.g., "the tall man in blue shirt says...")
- Write the EXACT spoken words in quotes — transcribe word-for-word
- Language spoken (Hindi, English, Urdu, Arabic, Punjabi, etc.)
- Tone of voice (whispering, shouting, emotional, calm, narrating, sarcastic, excited)
- Who speaks to whom (e.g., "the woman speaks to the child")
- Voiceover or narration: identify if it's a character on screen or an external narrator
- If there is NO dialogue in this segment, explicitly write: "No dialogue in this segment."
- DO NOT SUMMARIZE dialogue — write the ACTUAL words spoken

CAMERA:
- Movement (cinematic pan, static, handheld, drone, tracking, dolly, POV, crane)
- Angle (low angle, eye level, bird's eye, Dutch angle, over-the-shoulder)
- Framing (close-up, medium shot, wide shot, extreme close-up, two-shot)
- Lens feel (wide, telephoto, 35mm, shallow depth of field)

SETTING:
- Location (indoor/outdoor, specific place, city/rural)
- Props, furniture, decorations, background elements
- Time of day (dawn, morning, noon, golden hour, dusk, night)
- Weather/atmosphere if applicable

LIGHTING:
- Quality (golden hour, neon, soft diffused, harsh shadows, backlit, rim light)
- Color temperature and direction

AUDIO:
- Background music: genre, mood, instruments, tempo
- Sound effects: ambient sounds, nature, traffic, footsteps
- Music mood shifts between segments

OUTPUT FORMAT:

=== SEGMENT 1 (0:00 - 0:08) ===
[extremely detailed analysis of everything happening in this segment]

=== SEGMENT 2 (0:08 - 0:16) ===
[extremely detailed analysis]

=== SEGMENT 3 (0:16 - 0:24) ===
[extremely detailed analysis]

(continue for ALL ~8-second segments in the video)

Be EXHAUSTIVE. This analysis will be used to generate AI video prompts, so every visual, audio, character, and STYLE detail matters. Miss nothing.
The VISUAL STYLE section at the top is CRITICAL — it will be used in every generated prompt.
The LANGUAGE section is CRITICAL — all generated dialogue must match this language.

⚠️ DIALOGUE WARNING: If the video contains ANY spoken words, voiceover, or narration — you MUST transcribe them word-for-word in each segment. Do NOT skip or summarize dialogue. Omitting dialogue when it exists is a CRITICAL FAILURE.
"""

class VideoAnalyzer:
    def __init__(self, api_keys: List[str], prompt_text: Optional[str] = None):
        self.client = MultiKeyGeminiClient(api_keys)
        self.prompt_text = prompt_text or DEFAULT_PROMPT

    def set_prompt(self, new_prompt: str):
        self.prompt_text = new_prompt

    def analyze_video(self, video_path_or_url: str) -> dict:
        result = self.client.generate_content(video_path_or_url, self.prompt_text)
        if result is None:
            return {"status": "error", "message": "No result returned from Gemini."}
        
        # Try to extract language and visual style from result for structured output
        analysis_text = result
        
        # Return structured output with meta info
        output = {
            "status": "success",
            "youtube_url": video_path_or_url,
            "analyzed_at": datetime.utcnow().isoformat() + "Z",
            "active_key_used_suffix": self.client.get_active_key()[-8:],
            "analysis_text": analysis_text,
            "prompt_used": self.prompt_text,
        }
        return output


def main():
    parser = argparse.ArgumentParser(description="Analyze YouTube video with Gemini (multi-key rotation)")
    parser.add_argument("--youtube-url", type=str, required=True, help="YouTube video URL or local file path")
    parser.add_argument("--api-keys", type=str, required=True, help="Comma-separated list of Google Gemini API keys")
    parser.add_argument("--prompt-file", type=str, default=None, help="Optional file path with custom prompt text")
    parser.add_argument("--output-file", type=str, default="analysis_result.json", help="Where to save the JSON result")
    parser.add_argument("--prompt-text", type=str, default=None, help="Direct prompt text override")

    args = parser.parse_args()

    api_keys = [k.strip() for k in args.api_keys.split(",") if k.strip()]
    if not api_keys:
        print("Error: At least one API key must be provided.")
        sys.exit(1)

    prompt_text = DEFAULT_PROMPT
    if args.prompt_text:
        prompt_text = args.prompt_text
    elif args.prompt_file and os.path.isfile(args.prompt_file):
        with open(args.prompt_file, "r", encoding="utf-8") as f:
            prompt_text = f.read()

    analyzer = VideoAnalyzer(api_keys, prompt_text)
    
    try:
        result = analyzer.analyze_video(args.youtube_url)
    except Exception as e:
        result = {
            "status": "error",
            "message": str(e),
            "youtube_url": args.youtube_url,
            "analyzed_at": datetime.utcnow().isoformat() + "Z",
        }

    with open(args.output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "success" else 1


if __name__ == "__main__":
    sys.exit(main())
