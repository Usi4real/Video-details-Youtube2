import { pgTable, serial, text, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";

export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  keyText: text("key_text").notNull(),
  label: text("label").default("Unnamed Key"),
  isActive: boolean("is_active").default(true).notNull(),
  usageCount: integer("usage_count").default(0).notNull(),
  lastUsedAt: timestamp("last_used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const analysisPrompts = pgTable("analysis_prompts", {
  id: serial("id").primaryKey(),
  promptText: text("prompt_text").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const videoAnalyses = pgTable("video_analyses", {
  id: serial("id").primaryKey(),
  youtubeUrl: text("youtube_url").notNull(),
  status: text("status").default("pending").notNull(), // pending, running, completed, failed
  analysisResult: text("analysis_result"),
  activeApiKeySuffix: text("active_api_key_suffix"),
  promptTextUsed: text("prompt_text_used"),
  errorMessage: text("error_message"),
  convertedPrompts: text("converted_prompts"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});
