import { sql } from "drizzle-orm";
import { db } from "@/db";
import { apiKeys, analysisPrompts, videoAnalyses } from "@/db/schema";
import AnalysisDashboard from "./components/AnalysisDashboard";

export const dynamic = "force-dynamic";

function serializeRow<T extends Record<string, unknown>>(row: T): T {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(row)) {
    if (value instanceof Date) {
      result[key] = value.toISOString();
    } else {
      result[key] = value;
    }
  }
  return result as T;
}

export default async function HomePage() {
  await db.execute(sql`select 1`);

  const keysRaw = await db.select().from(apiKeys);
  const promptsRaw = await db.select().from(analysisPrompts);
  const analysesRaw = await db.select().from(videoAnalyses).orderBy(sql`${videoAnalyses.createdAt} DESC`).limit(10);

  const keys = keysRaw.map(serializeRow);
  const prompts = promptsRaw.map(serializeRow);
  const analyses = analysesRaw.map(serializeRow);

  return <AnalysisDashboard
    initialKeys={keys as any}
    initialPrompts={prompts as any}
    initialAnalyses={analyses as any}
  />;
}
