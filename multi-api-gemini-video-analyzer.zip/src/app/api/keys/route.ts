import { NextResponse } from "next/server";
import { db } from "@/db";
import { apiKeys } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(apiKeys);
    return NextResponse.json({ keys: rows });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { keyText, label } = body;
    if (!keyText || !keyText.trim()) {
      return NextResponse.json({ error: "API key is required" }, { status: 400 });
    }
    const [row] = await db.insert(apiKeys).values({
      keyText: keyText.trim(),
      label: label || "Unnamed Key",
      isActive: true,
      usageCount: 0,
    }).returning();
    return NextResponse.json(row);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const body = await req.json();
    const { id } = body;
    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }
    await db.delete(apiKeys).where(eq(apiKeys.id, id));
    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
