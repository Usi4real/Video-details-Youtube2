import { NextResponse } from "next/server";
import { db } from "@/db";
import { videoAnalyses } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(videoAnalyses).orderBy(desc(videoAnalyses.createdAt)).limit(20);
    return NextResponse.json({ analyses: rows });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
