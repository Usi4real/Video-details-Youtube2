import { NextResponse } from "next/server";
import { db } from "@/db";
import { analysisPrompts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(analysisPrompts).orderBy(desc(analysisPrompts.createdAt));
    return NextResponse.json({ prompts: rows });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { promptText } = body;
    if (!promptText || !promptText.trim()) {
      return NextResponse.json({ error: "Prompt text is required" }, { status: 400 });
    }
    // Deactivate all existing prompts and insert new active one
    await db.update(analysisPrompts).set({ isActive: false }).execute();
    const [row] = await db.insert(analysisPrompts).values({
      promptText: promptText.trim(),
      isActive: true,
    }).returning();
    return NextResponse.json(row);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
