import { NextResponse } from "next/server";
import { db } from "@/db";
import { apiKeys, analysisPrompts, videoAnalyses } from "@/db/schema";
import { sql } from "drizzle-orm";
import { spawn } from "child_process";
import path from "path";

export async function POST(req: Request) {
  try {
    let youtubeUrl: string | null = null;
    let promptText: string | null = null;
    let videoFilePath: string | null = null;
    let uploadedFileName = "";

    const contentType = req.headers.get("content-type") || "";
    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const urlField = formData.get("youtubeUrl");
      youtubeUrl = urlField ? (urlField as string).trim() : null;
      const promptField = formData.get("promptText");
      promptText = promptField ? (promptField as string).trim() : null;
      const fileField = formData.get("videoFile");
      if (fileField && fileField instanceof File) {
        const fsPromises = await import("fs/promises");
        const tempDir = path.join(process.cwd(), "temp_uploads");
        try {
          await fsPromises.mkdir(tempDir, { recursive: true });
        } catch (e) {
          // Ignore
        }
        const buffer = Buffer.from(await fileField.arrayBuffer());
        uploadedFileName = fileField.name || `upload_${Date.now()}`;
        videoFilePath = path.join(tempDir, uploadedFileName);
        await fsPromises.writeFile(videoFilePath, buffer);
      }
    } else {
      const body = await req.json();
      youtubeUrl = body.youtubeUrl ? body.youtubeUrl.trim() : null;
      promptText = body.promptText ? body.promptText.trim() : null;
    }

    if (!youtubeUrl && !videoFilePath) {
      return NextResponse.json({ error: "YouTube URL or video file is required" }, { status: 400 });
    }

    // Get active API keys
    const keys = await db.select().from(apiKeys).where(sql`${apiKeys.isActive} = true`);
    if (keys.length === 0) {
      return NextResponse.json({ error: "No active API keys found. Please add at least one." }, { status: 400 });
    }

    // Get active prompt
    let promptTextUsed = promptText;
    if (!promptTextUsed) {
      const activePrompt = await db.select().from(analysisPrompts).where(sql`${analysisPrompts.isActive} = true`).limit(1);
      promptTextUsed = activePrompt[0]?.promptText || "";
    }

    const videoPathForPython = videoFilePath || youtubeUrl || "";
    const youtubeUrlForDB = youtubeUrl || (videoFilePath ? `uploaded_video: ${uploadedFileName}` : "");

    // Create pending analysis record
    const [analysisRecord] = await db.insert(videoAnalyses).values({
      youtubeUrl: youtubeUrlForDB,
      status: "running",
      promptTextUsed: promptTextUsed,
    }).returning();

    // Write prompt to temporary file to avoid command line length limits
    const fsPromises = await import("fs/promises");
    const promptFilePath = path.join(process.cwd(), `prompt_${analysisRecord.id}.txt`);
    await fsPromises.writeFile(promptFilePath, promptTextUsed || "", "utf-8");

    // Prepare Python command
    const pythonScript = path.join(process.cwd(), "python_app", "analyzer.py");
    const apiKeysString = keys.map((k: any) => k.keyText).join(",");

    const pythonProcess = spawn("python3", [
      pythonScript,
      "--youtube-url", videoPathForPython,
      "--api-keys", apiKeysString,
      "--prompt-file", promptFilePath,
      "--output-file", `analysis_result_${analysisRecord.id}.json`,
    ], {
      cwd: process.cwd(),
      env: { ...process.env },
      detached: false,
    });

    let stdoutData = "";
    let stderrData = "";

    pythonProcess.stdout.on("data", (data) => {
      stdoutData += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      stderrData += data.toString();
    });

    pythonProcess.on("close", async (code) => {
      try {
        const outputFile = path.join(process.cwd(), `analysis_result_${analysisRecord.id}.json`);
        // Try to read output file first
        let fileData = null;
        try {
          const fsRead = await import("fs/promises");
          fileData = await fsRead.readFile(outputFile, "utf-8");
        } catch (e) {
          // File may not exist
        }
        const combinedData = (fileData || stdoutData || "").toString();
        let resultText = combinedData;
        let status = "completed";
        let errorMsg = null;

        if (code !== 0) {
          status = "failed";
          errorMsg = stderrData || stdoutData || `Python process exited with code ${code}`;
        }

        if (status === "completed") {
          try {
            const parsed = JSON.parse(combinedData);
            if (parsed.status === "success") {
              resultText = parsed.analysis_text || combinedData;
            } else {
              status = "failed";
              errorMsg = parsed.message || combinedData;
              resultText = combinedData;
            }
          } catch (e) {
            // Not JSON, treat as raw result
            resultText = combinedData;
          }
        } else if (status === "failed") {
          resultText = stdoutData || stderrData || combinedData || "Unknown error during analysis.";
        }

        await db.update(videoAnalyses)
          .set({
            status,
            analysisResult: resultText,
            errorMessage: errorMsg,
            completedAt: new Date(),
            activeApiKeySuffix: (() => {
              try {
                const p = JSON.parse(combinedData);
                return p.active_key_used_suffix || null;
              } catch (e) {
                return null;
              }
            })(),
          })
          .where(sql`${videoAnalyses.id} = ${analysisRecord.id}`);

        // Clean up files
        try {
          const fs = await import("fs/promises");
          await fs.unlink(outputFile).catch(() => {});
          await fs.unlink(promptFilePath).catch(() => {});
          if (videoFilePath) {
            await fs.unlink(videoFilePath).catch(() => {});
          }
        } catch (e) {
          // Ignore cleanup errors
        }
      } catch (dbErr: any) {
        console.error("DB update error after analysis:", dbErr);
      }
    });

    return NextResponse.json({ analysis: analysisRecord, message: "Analysis started. It may take a few minutes depending on video length." });
  } catch (e: any) {
    console.error("Analyze error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
