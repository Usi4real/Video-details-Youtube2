import { NextResponse } from "next/server";
import { db } from "@/db";
import { apiKeys, videoAnalyses } from "@/db/schema";
import { sql, eq } from "drizzle-orm";
import { spawn } from "child_process";
import path from "path";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { analysisId, analysisText } = body;

    if (!analysisId && !analysisText) {
      return NextResponse.json({ error: "analysisId or analysisText is required" }, { status: 400 });
    }

    // Get active API keys
    const keys = await db.select().from(apiKeys).where(sql`${apiKeys.isActive} = true`);
    if (keys.length === 0) {
      return NextResponse.json({ error: "No active API keys found. Please add at least one." }, { status: 400 });
    }

    let textToConvert = analysisText || "";
    let analysisRecordId: number | null = null;

    if (analysisId) {
      const records = await db.select().from(videoAnalyses).where(sql`${videoAnalyses.id} = ${analysisId}`).limit(1);
      if (records.length === 0) {
        return NextResponse.json({ error: "Analysis not found" }, { status: 404 });
      }
      analysisRecordId = records[0].id;
      textToConvert = records[0].analysisResult || analysisText || "";
    }

    if (!textToConvert || textToConvert.trim().length < 10) {
      return NextResponse.json({ error: "No analysis text available for conversion" }, { status: 400 });
    }

    // Write analysis text to temporary file
    const fsPromises = await import("fs/promises");
    const tempDir = path.join(process.cwd(), "temp_conversions");
    try {
      await fsPromises.mkdir(tempDir, { recursive: true });
    } catch (e) {
      // Ignore
    }

    const analysisFilePath = path.join(tempDir, `analysis_for_convert_${analysisRecordId || Date.now()}.txt`);
    await fsPromises.writeFile(analysisFilePath, textToConvert, "utf-8");

    // Create/update analysis record status to running for conversion
    if (analysisRecordId) {
      await db.update(videoAnalyses)
        .set({ status: "converting" })
        .where(eq(videoAnalyses.id, analysisRecordId));
    }

    const pythonScript = path.join(process.cwd(), "python_app", "convert_to_prompts.py");
    const apiKeysString = keys.map((k: any) => k.keyText).join(",");

    const outputFilePath = path.join(tempDir, `converted_result_${analysisRecordId || Date.now()}.json`);

    const pythonProcess = spawn("python3", [
      pythonScript,
      "--analysis-file", analysisFilePath,
      "--api-keys", apiKeysString,
      "--output-file", outputFilePath,
    ], {
      cwd: process.cwd(),
      env: { ...process.env },
      detached: false,
    });

    let stdoutData = "";
    let stderrData = "";

    pythonProcess.stdout.on("data", (data) => {
      stdoutData += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      stderrData += data.toString();
    });

    pythonProcess.on("close", async (code) => {
      try {
        let fileData = null;
        try {
          const fsRead = await import("fs/promises");
          fileData = await fsRead.readFile(outputFilePath, "utf-8");
        } catch (e) {
          // Ignore
        }
        const combinedData = (fileData || stdoutData || "").toString();
        let convertedText = combinedData;
        let conversionStatus = "completed";

        if (code !== 0) {
          conversionStatus = "failed";
          convertedText = stderrData || stdoutData || `Process exited with code ${code}`;
        } else {
          try {
            const parsed = JSON.parse(combinedData);
            if (parsed.status === "success") {
              convertedText = parsed.result || combinedData;
            } else {
              conversionStatus = "failed";
              convertedText = parsed.result || combinedData;
            }
          } catch (e) {
            convertedText = combinedData;
          }
        }

        if (analysisRecordId) {
          await db.update(videoAnalyses)
            .set({
              convertedPrompts: convertedText,
              status: conversionStatus === "failed" ? "failed" : "completed",
            })
            .where(eq(videoAnalyses.id, analysisRecordId));
        }

        try {
          const fs = await import("fs/promises");
          await fs.unlink(outputFilePath).catch(() => {});
          await fs.unlink(analysisFilePath).catch(() => {});
        } catch (e) {
          // Ignore cleanup errors
        }
      } catch (dbErr: any) {
        console.error("DB update error after conversion:", dbErr);
      }
    });

    return NextResponse.json({
      analysisRecordId,
      message: "Conversion started. It may take a few minutes.",
      status: "running"
    });
  } catch (e: any) {
    console.error("Convert error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
