"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface ApiKeyRow {
  id: number;
  keyText: string;
  label: string;
  isActive: boolean;
  usageCount: number;
  lastUsedAt: string | null;
  createdAt: string;
}

interface PromptRow {
  id: number;
  promptText: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface AnalysisRow {
  id: number;
  youtubeUrl: string;
  status: string;
  analysisResult: string | null;
  activeApiKeySuffix: string | null;
  promptTextUsed: string | null;
  errorMessage: string | null;
  convertedPrompts: string | null;
  createdAt: string;
  completedAt: string | null;
}

export default function AnalysisDashboard({
  initialKeys,
  initialPrompts,
  initialAnalyses,
}: {
  initialKeys: ApiKeyRow[];
  initialPrompts: PromptRow[];
  initialAnalyses: AnalysisRow[];
}) {
  const router = useRouter();
  const [keys, setKeys] = useState<ApiKeyRow[]>(initialKeys);
  const [prompts, setPrompts] = useState<PromptRow[]>(initialPrompts);
  const [analyses, setAnalyses] = useState<AnalysisRow[]>(initialAnalyses);

  const [newKeyText, setNewKeyText] = useState("");
  const [newKeyLabel, setNewKeyLabel] = useState("");
  const [youtubeUrl, setYoutubeUrl] = useState("https://www.youtube.com/watch?v=pJ1TSCWc44Y");
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisStatus, setAnalysisStatus] = useState<string | null>(null);
  const [convertingIds, setConvertingIds] = useState<Set<number>>(new Set());

  const [currentPromptText, setCurrentPromptText] = useState(
    initialPrompts.find((p) => p.isActive)?.promptText ||
    "You are an expert video analyst. Watch the following video with EXTREME attention to detail and produce a comprehensive, scene-by-scene analysis..."
  );

  // Re-fetch analyses when needed
  const refreshAnalyses = async () => {
    try {
      const res = await fetch("/api/analyses");
      const data = await res.json();
      if (data.analyses) setAnalyses(data.analyses);
    } catch (e) {
      console.error("Refresh failed", e);
    }
  };

  // Add API Key
  const handleAddKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyText.trim()) return;
    try {
      const res = await fetch("/api/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyText: newKeyText.trim(), label: newKeyLabel.trim() || "Unnamed Key" }),
      });
      const data = await res.json();
      if (data.error) {
        alert("Failed to add key: " + data.error);
      } else {
        setKeys([...keys, data]);
        setNewKeyText("");
        setNewKeyLabel("");
      }
    } catch (e) {
      alert("Error adding key");
    }
  };

  const handleDeleteKey = async (id: number) => {
    if (!confirm("Delete this API key?")) return;
    await fetch("/api/keys", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    setKeys(keys.filter((k) => k.id !== id));
  };

  // Update Prompt
  const handleUpdatePrompt = async () => {
    try {
      const res = await fetch("/api/prompts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ promptText: currentPromptText }),
      });
      const data = await res.json();
      if (data.error) {
        alert("Failed to update prompt: " + data.error);
      } else {
        // Refresh prompts list
        const promptsRes = await fetch("/api/prompts");
        const promptsData = await promptsRes.json();
        if (promptsData.prompts) setPrompts(promptsData.prompts);
        alert("Prompt updated successfully!");
      }
    } catch (e) {
      alert("Error updating prompt");
    }
  };

  // Start Analysis
  const handleConvertToPrompts = async (analysisId: number) => {
    setConvertingIds((prev) => new Set(prev).add(analysisId));
    try {
      const res = await fetch("/api/convert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ analysisId }),
      });
      const data = await res.json();
      if (data.error) {
        alert("Conversion failed: " + data.error);
      } else {
        alert("Conversion started! Results will appear shortly. Refresh the page to see them.");
      }
      setTimeout(() => refreshAnalyses(), 3000);
    } catch (e: any) {
      alert("Conversion error: " + (e.message || "Unknown"));
    } finally {
      setConvertingIds((prev) => {
        const next = new Set(prev);
        next.delete(analysisId);
        return next;
      });
    }
  };

  const handleAnalyze = async () => {
    if (!youtubeUrl.trim() && !videoFile) return;
    setIsAnalyzing(true);
    setAnalysisStatus("Starting analysis...");
    try {
      let res;
      if (videoFile) {
        const formData = new FormData();
        formData.append("videoFile", videoFile);
        formData.append("promptText", currentPromptText);
        if (youtubeUrl.trim()) formData.append("youtubeUrl", youtubeUrl.trim());
        res = await fetch("/api/analyze", {
          method: "POST",
          body: formData,
        });
      } else {
        res = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ youtubeUrl, promptText: currentPromptText }),
        });
      }
      const data = await res.json();
      if (data.error) {
        setAnalysisStatus("Failed: " + data.error);
        alert("Analysis failed: " + data.error);
      } else {
        setAnalysisStatus("Analysis completed!");
        refreshAnalyses();
        setVideoFile(null);
      }
    } catch (e: any) {
      setAnalysisStatus("Failed: " + (e.message || "Unknown error"));
      alert("Analysis failed");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Use the full user prompt as default if available, else the detailed one
  const displayPrompt = initialPrompts.find((p) => p.isActive)?.promptText || currentPromptText;

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-50 px-6 py-12">
      <div className="max-w-6xl mx-auto space-y-16">
        {/* Header */}
        <section className="text-center space-y-4">
          <h1 className="text-5xl md:text-6xl font-extrabold bg-gradient-to-r from-amber-300 via-rose-300 to-violet-300 bg-clip-text text-transparent tracking-tight">
            Video Analyst
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Analyze YouTube videos with Google Gemini using multiple rotating API keys. Convert video content into detailed scene descriptions for AI image and video prompt generation.
          </p>
          <div className="inline-flex items-center gap-2 bg-slate-800/60 border border-slate-700 rounded-full px-4 py-1.5 text-sm text-amber-300 font-medium shadow-inner shadow-amber-900/20">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            Multi-Key Rotation Enabled
          </div>
        </section>

        {/* Prompt Editor */}
        <section className="rounded-3xl bg-slate-900/60 border border-slate-800 p-8 shadow-2xl backdrop-blur-xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-amber-200">Analysis Prompt</h2>
            <button
              onClick={handleUpdatePrompt}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition shadow-lg shadow-amber-500/20"
            >
              Save Prompt
            </button>
          </div>
          <textarea
            value={currentPromptText}
            onChange={(e) => setCurrentPromptText(e.target.value)}
            rows={14}
            className="w-full bg-slate-950/60 border border-slate-700 rounded-2xl p-5 text-sm font-mono text-slate-200 leading-relaxed focus:outline-none focus:ring-2 focus:ring-amber-500/40 resize-y"
          />
          <p className="text-xs text-slate-500 mt-3">This prompt will be used for every analysis. Update it anytime to change extraction behavior.</p>
        </section>

        {/* API Keys Manager */}
        <section className="rounded-3xl bg-slate-900/60 border border-slate-800 p-8 shadow-2xl backdrop-blur-xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-violet-200">Gemini API Keys</h2>
              <p className="text-slate-400 text-sm">Add as many keys as you want. The system will rotate automatically when quota is exhausted.</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-extrabold text-violet-300">{keys.length}</div>
              <div className="text-xs text-slate-500 uppercase tracking-widest">Active Keys</div>
            </div>
          </div>

          <form onSubmit={handleAddKey} className="flex flex-wrap gap-3 mb-6">
            <input
              type="text"
              placeholder="Paste Google Gemini API Key..."
              value={newKeyText}
              onChange={(e) => setNewKeyText(e.target.value)}
              className="flex-1 min-w-[16rem] bg-slate-950/60 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
            />
            <input
              type="text"
              placeholder="Label (optional)"
              value={newKeyLabel}
              onChange={(e) => setNewKeyLabel(e.target.value)}
              className="w-48 bg-slate-950/60 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-violet-600 hover:bg-violet-500 text-white font-bold rounded-xl transition shadow-lg shadow-violet-600/20"
            >
              Add Key
            </button>
          </form>

          <div className="space-y-3">
            {keys.length === 0 && (
              <div className="text-center py-8 text-slate-600 text-sm">No API keys added yet. Add at least one to begin analysis.</div>
            )}
            {keys.map((k) => (
              <div key={k.id} className="flex items-center justify-between bg-slate-950/40 border border-slate-800 rounded-xl px-4 py-3 hover:border-slate-600 transition">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="w-2.5 h-2.5 rounded-full bg-violet-400 shrink-0" />
                  <div className="min-w-0">
                    <div className="font-semibold text-sm text-slate-100 truncate">{k.label}</div>
                    <div className="text-xs text-slate-500 font-mono truncate">{k.keyText.slice(0, 16)}...{k.keyText.slice(-8)}</div>
                  </div>
                  <div className="text-xs text-slate-400">Usage: {k.usageCount}</div>
                </div>
                <button
                  onClick={() => handleDeleteKey(k.id)}
                  className="ml-4 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-900/30 px-2 py-1 rounded-md transition"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Video Analysis Section */}
        <section className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800/60 to-slate-900 border border-amber-900/30 p-8 shadow-2xl">
          <h2 className="text-2xl font-bold text-amber-200 mb-2">Analyze Video</h2>
          <p className="text-slate-400 text-sm mb-6">Enter a YouTube URL or upload a video file directly. The app will use the current prompt and rotate through your API keys if quotas are hit.</p>

          <div className="flex flex-wrap gap-3 mb-4">
            <input
              type="text"
              value={youtubeUrl}
              onChange={(e) => setYoutubeUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="flex-1 min-w-[16rem] bg-slate-950/60 border border-slate-700 rounded-xl px-5 py-3.5 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3 mb-4">
            <label className="inline-flex items-center gap-2 px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white text-sm font-bold rounded-xl cursor-pointer transition shadow-lg shadow-violet-600/20">
              <span>Upload Video File</span>
              <input
                type="file"
                accept="video/*"
                onChange={(e) => setVideoFile(e.target.files ? e.target.files[0] : null)}
                className="hidden"
              />
            </label>
            {videoFile && (
              <span className="text-xs text-amber-300 font-medium truncate max-w-xs">{videoFile.name} ({(videoFile.size / (1024 * 1024)).toFixed(1)} MB)</span>
            )}
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || keys.length === 0 || (!youtubeUrl.trim() && !videoFile)}
              className="px-8 py-3.5 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-extrabold rounded-xl transition shadow-xl shadow-amber-900/20"
            >
              {isAnalyzing ? "Analyzing..." : videoFile ? "Analyze Uploaded Video" : "Analyze YouTube URL"}
            </button>
          </div>

          {analysisStatus && (
            <div className="text-sm font-medium text-amber-300 mb-2">{analysisStatus}</div>
          )}

          {keys.length === 0 && (
            <div className="text-rose-400 text-sm">Please add at least one Gemini API key before analyzing.</div>
          )}
        </section>

        {/* Results */}
        <section className="rounded-3xl bg-slate-900/40 border border-slate-800 p-8 shadow-2xl backdrop-blur-xl">
          <h2 className="text-2xl font-bold text-rose-200 mb-6">Recent Analyses</h2>

          {analyses.length === 0 ? (
            <div className="text-center py-12 text-slate-600">No analyses yet. Run your first analysis above.</div>
          ) : (
            <div className="space-y-6">
              {analyses.map((a) => (
                <div key={a.id} className="bg-slate-950/30 border border-slate-800 rounded-2xl p-6 hover:border-rose-800/40 transition">
                  <div className="flex items-center justify-between mb-3">
                    <a href={a.youtubeUrl} target="_blank" rel="noopener noreferrer" className="text-sm font-semibold text-blue-300 hover:text-blue-200 truncate max-w-md hover:underline">
                      {a.youtubeUrl}
                    </a>
                    <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide ${
                      a.status === "completed" ? "bg-green-900/40 text-green-300 border border-green-700" :
                      a.status === "failed" ? "bg-rose-900/40 text-rose-300 border border-rose-700" :
                      a.status === "running" ? "bg-amber-900/40 text-amber-300 border border-amber-700" :
                      "bg-slate-800 text-slate-400 border border-slate-700"
                    }`}>
                      {a.status}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 mb-3">Analyzed: {new Date(a.createdAt).toLocaleString()}</div>
                  {a.errorMessage && (
                    <div className="text-rose-400 text-sm bg-rose-950/30 border border-rose-900 rounded-xl p-3 mb-3">{a.errorMessage}</div>
                  )}
                  {a.analysisResult ? (
                    <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-5 max-h-96 overflow-y-auto">
                      <pre className="text-xs text-slate-300 font-mono whitespace-pre-wrap leading-relaxed">{a.analysisResult}</pre>
                    </div>
                  ) : (
                    <div className="text-slate-500 text-sm">No result available yet.</div>
                  )}
                  <div className="mt-4 flex flex-wrap gap-3">
                    <button
                      onClick={() => handleConvertToPrompts(a.id)}
                      disabled={convertingIds.has(a.id)}
                      className="px-5 py-2.5 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 disabled:opacity-40 text-white text-sm font-bold rounded-xl transition shadow-lg shadow-violet-900/20"
                    >
                      {convertingIds.has(a.id) ? "Converting..." : "Convert to Image/Video Prompts"}
                    </button>
                  </div>
                  {a.convertedPrompts ? (
                    <div className="mt-4 bg-gradient-to-br from-violet-950/40 via-fuchsia-950/30 to-violet-950/40 border border-violet-800/40 rounded-2xl p-6">
                      <h3 className="text-lg font-bold text-violet-200 mb-3">Converted Prompts</h3>
                      <pre className="text-xs text-slate-200 font-mono whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">{a.convertedPrompts}</pre>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
