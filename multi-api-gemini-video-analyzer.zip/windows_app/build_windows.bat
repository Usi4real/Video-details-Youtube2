@echo off
setlocal EnableExtensions
cd /d "%~dp0.."

echo ========================================
echo Video Analyst Windows Installer Builder
echo ========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python 3 was not found. Install Python 3.11 or newer from python.org.
  pause
  exit /b 1
)

if not exist ".venv-win\Scripts\python.exe" (
  echo Creating build environment...
  py -3 -m venv .venv-win
  if errorlevel 1 goto :failed
)

call ".venv-win\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r windows_app\requirements.txt
if errorlevel 1 goto :failed

echo.
echo Building VideoAnalyst.exe...
python -m PyInstaller --clean --noconfirm windows_app\VideoAnalyst.spec
if errorlevel 1 goto :failed
if not exist "windows_app\dist\VideoAnalyst.exe" goto :failed

echo.
echo Looking for Inno Setup...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup 6 was not found.
  echo Install it from https://jrsoftware.org/isinfo.php and run this file again.
  echo The executable is still available at windows_app\dist\VideoAnalyst.exe
  pause
  exit /b 0
)

if exist "windows_app\installer_output" rmdir /s /q "windows_app\installer_output"
mkdir "windows_app\installer_output"
"%ISCC%" "windows_app\installer\VideoAnalyst.iss"
if errorlevel 1 goto :failed

if not exist "windows_app\installer_output\VideoAnalyst-Installer.exe" goto :failed

echo.
echo SUCCESS!
echo Installer: %CD%\windows_app\installer_output\VideoAnalyst-Installer.exe
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Review the error above.
pause
exit /b 1
