; Inno Setup installer for Video Analyst
#define MyAppName "Video Analyst"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Video Analyst"
#define MyAppExeName "VideoAnalyst.exe"

[Setup]
AppId={{B4E46DD2-1F1F-4A85-9C95-7E2D8B7C0A11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Video Analyst
DefaultGroupName={#MyAppName}
OutputDir=..\installer_output
OutputBaseFilename=VideoAnalyst-Installer
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\{#MyAppExeName}
DisableProgramGroupPage=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\dist\VideoAnalyst.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent

; User data in %LOCALAPPDATA%\VideoAnalyst is intentionally preserved on uninstall.
