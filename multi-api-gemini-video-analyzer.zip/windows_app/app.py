#!/usr/bin/env python3
"""Video Analyst standalone Windows desktop application."""
from __future__ import annotations

import os
import sqlite3
import sys
import threading
from pathlib import Path
from typing import Any

# In a PyInstaller build, bundled Python modules are unpacked below _MEIPASS.
if getattr(sys, "frozen", False):
    BUNDLE_ROOT = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
else:
    BUNDLE_ROOT = Path(__file__).resolve().parents[1]
if str(BUNDLE_ROOT) not in sys.path:
    sys.path.insert(0, str(BUNDLE_ROOT))

import customtkinter as ctk
from tkinter import filedialog, messagebox

from python_app.analyzer import DEFAULT_PROMPT, VideoAnalyzer
from python_app.convert_to_prompts import PromptConverter


APP_NAME = "Video Analyst"
APP_DATA_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "VideoAnalyst"
APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = Path(os.environ.get("VIDEO_ANALYST_DB", APP_DATA_DIR / "video_analyst.sqlite3"))

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

FONT_TITLE = ctk.CTkFont(family="Segoe UI", size=30, weight="bold")
FONT_SECTION = ctk.CTkFont(family="Segoe UI", size=18, weight="bold")
FONT_BODY = ctk.CTkFont(family="Segoe UI", size=13)
FONT_SMALL = ctk.CTkFont(family="Segoe UI", size=11)
FONT_MONO = ctk.CTkFont(family="Consolas", size=11)


def connect_db() -> sqlite3.Connection:
    connection = sqlite3.connect(str(DB_PATH), timeout=30)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_db() -> None:
    with connect_db() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_text TEXT NOT NULL,
                label TEXT NOT NULL DEFAULT 'Unnamed Key',
                is_active INTEGER NOT NULL DEFAULT 1,
                usage_count INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS analysis_prompts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prompt_text TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS video_analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                youtube_url TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                analysis_result TEXT,
                active_api_key_suffix TEXT,
                prompt_text_used TEXT,
                error_message TEXT,
                converted_prompts TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                completed_at TEXT
            );
            """
        )
        # Keep older local desktop databases compatible if the app is upgraded.
        columns = {row["name"] for row in connection.execute("PRAGMA table_info(video_analyses)")}
        if "converted_prompts" not in columns:
            connection.execute("ALTER TABLE video_analyses ADD COLUMN converted_prompts TEXT")
        active = connection.execute(
            "SELECT id FROM analysis_prompts WHERE is_active = 1 ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if active is None:
            connection.execute(
                "INSERT INTO analysis_prompts (prompt_text, is_active) VALUES (?, 1)",
                (DEFAULT_PROMPT,),
            )


class VideoAnalystApp(ctk.CTk):
    def __init__(self) -> None:
        initialize_db()
        super().__init__()
        self.title("Video Analyst — AI Scene Analysis & Prompt Generator")
        self.geometry("1220x900")
        self.minsize(980, 680)
        self.configure(fg_color="#0c0d16")

        self.keys: list[dict[str, Any]] = []
        self.analyses: list[dict[str, Any]] = []
        self.current_video_path: str | None = None
        self.active_prompt = DEFAULT_PROMPT

        self.build_ui()
        self.refresh_all()

    def build_ui(self) -> None:
        header = ctk.CTkFrame(self, fg_color="#10111d", corner_radius=0, height=112)
        header.pack(fill="x")
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="Video Analyst", font=FONT_TITLE, text_color="#f6c85f").pack(pady=(20, 2))
        ctk.CTkLabel(
            header,
            text="Gemini scene analysis • image/video prompt generation • automatic API-key rotation",
            font=FONT_BODY,
            text_color="#9da1b4",
        ).pack()

        self.content = ctk.CTkScrollableFrame(self, fg_color="#0c0d16")
        self.content.pack(fill="both", expand=True, padx=18, pady=16)

        self.build_prompt_section()
        self.build_keys_section()
        self.build_analyze_section()
        self.build_results_section()

        footer = ctk.CTkFrame(self.content, fg_color="#151726", corner_radius=12)
        footer.pack(fill="x", pady=(8, 20))
        self.db_label = ctk.CTkLabel(
            footer,
            text=f"Local data: {DB_PATH}",
            font=FONT_SMALL,
            text_color="#74798f",
        )
        self.db_label.pack(pady=(10, 2))
        ctk.CTkButton(
            footer,
            text="Refresh",
            width=110,
            height=30,
            command=self.refresh_all,
            fg_color="#2b2f48",
            hover_color="#3b4163",
        ).pack(pady=(2, 10))

    def section(self, title: str, color: str) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content, fg_color="#171927", corner_radius=16)
        frame.pack(fill="x", pady=8)
        ctk.CTkLabel(frame, text=title, font=FONT_SECTION, text_color=color).pack(
            anchor="w", padx=18, pady=(16, 8)
        )
        return frame

    # ---------------- Prompt ----------------
    def build_prompt_section(self) -> None:
        frame = self.section("Analysis Prompt", "#f6c85f")
        self.prompt_box = ctk.CTkTextbox(
            frame,
            height=180,
            font=FONT_MONO,
            wrap="word",
            fg_color="#0f101a",
            border_width=1,
            border_color="#2e3146",
        )
        self.prompt_box.pack(fill="x", padx=18, pady=(0, 8))
        self.prompt_box.insert("1.0", DEFAULT_PROMPT)
        self.prompt_box.configure(state="disabled")

        row = ctk.CTkFrame(frame, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=(0, 16))
        ctk.CTkButton(row, text="Edit", width=100, height=32, command=self.toggle_prompt).pack(side="left")
        ctk.CTkButton(
            row,
            text="Save Prompt",
            width=130,
            height=32,
            command=self.save_prompt,
            fg_color="#ad7d20",
            hover_color="#c8962a",
        ).pack(side="left", padx=8)
        ctk.CTkLabel(
            row,
            text="The saved prompt is used for the next analysis.",
            font=FONT_SMALL,
            text_color="#777c91",
        ).pack(side="left", padx=8)

    def toggle_prompt(self) -> None:
        state = self.prompt_box.cget("state")
        self.prompt_box.configure(state="normal" if state == "disabled" else "disabled")

    def save_prompt(self) -> None:
        prompt = self.prompt_box.get("1.0", "end").strip()
        if not prompt:
            messagebox.showwarning("Prompt required", "The analysis prompt cannot be empty.")
            return
        try:
            with connect_db() as connection:
                connection.execute("UPDATE analysis_prompts SET is_active = 0")
                connection.execute(
                    "INSERT INTO analysis_prompts (prompt_text, is_active) VALUES (?, 1)",
                    (prompt,),
                )
            self.prompt_box.configure(state="disabled")
            self.active_prompt = prompt
            messagebox.showinfo("Saved", "Analysis prompt saved.")
        except Exception as error:
            messagebox.showerror("Save failed", str(error))

    # ---------------- API keys ----------------
    def build_keys_section(self) -> None:
        frame = self.section("Gemini API Keys", "#b99aff")
        ctk.CTkLabel(
            frame,
            text="Add multiple keys. The Gemini client automatically moves to the next key when quota is exhausted.",
            font=FONT_SMALL,
            text_color="#969bb1",
        ).pack(anchor="w", padx=18, pady=(0, 8))

        form = ctk.CTkFrame(frame, fg_color="#10111d", corner_radius=10)
        form.pack(fill="x", padx=18, pady=(0, 8))
        self.key_entry = ctk.CTkEntry(form, placeholder_text="Paste Google Gemini API key", font=FONT_MONO, height=34)
        self.key_entry.pack(side="left", fill="x", expand=True, padx=(10, 5), pady=10)
        self.label_entry = ctk.CTkEntry(form, placeholder_text="Label (optional)", width=170, height=34)
        self.label_entry.pack(side="left", padx=5, pady=10)
        ctk.CTkButton(form, text="Add Key", width=100, height=34, command=self.add_key).pack(side="left", padx=(5, 10), pady=10)

        self.keys_list = ctk.CTkFrame(frame, fg_color="#10111d", corner_radius=10)
        self.keys_list.pack(fill="x", padx=18, pady=(0, 16))

    def add_key(self) -> None:
        value = self.key_entry.get().strip()
        label = self.label_entry.get().strip() or "Unnamed Key"
        if not value:
            messagebox.showwarning("Key required", "Paste a Gemini API key first.")
            return
        try:
            with connect_db() as connection:
                connection.execute(
                    "INSERT INTO api_keys (key_text, label, is_active) VALUES (?, ?, 1)",
                    (value, label),
                )
            self.key_entry.delete(0, "end")
            self.label_entry.delete(0, "end")
            self.refresh_all()
        except Exception as error:
            messagebox.showerror("Could not add key", str(error))

    def remove_key(self, key_id: int) -> None:
        if not messagebox.askyesno("Remove key", "Remove this Gemini API key from the local app?"):
            return
        with connect_db() as connection:
            connection.execute("DELETE FROM api_keys WHERE id = ?", (key_id,))
        self.refresh_all()

    def render_keys(self) -> None:
        for child in self.keys_list.winfo_children():
            child.destroy()
        if not self.keys:
            ctk.CTkLabel(self.keys_list, text="No keys added yet.", font=FONT_BODY, text_color="#777c91").pack(pady=18)
            return
        for item in self.keys:
            row = ctk.CTkFrame(self.keys_list, fg_color="#1a1c2d", corner_radius=8)
            row.pack(fill="x", padx=8, pady=4)
            suffix = item["key_text"][-8:] if len(item["key_text"]) > 8 else item["key_text"]
            ctk.CTkLabel(
                row,
                text=f"{item['label']}  •  ...{suffix}  •  usage: {item['usage_count']}",
                font=FONT_MONO,
                text_color="#e1e3f5",
                anchor="w",
            ).pack(side="left", fill="x", expand=True, padx=10, pady=8)
            ctk.CTkButton(
                row,
                text="Remove",
                width=80,
                height=28,
                command=lambda key_id=item["id"]: self.remove_key(key_id),
                fg_color="#51233e",
                hover_color="#733052",
            ).pack(side="right", padx=8, pady=6)

    # ---------------- Analyze ----------------
    def build_analyze_section(self) -> None:
        frame = self.section("Analyze Video", "#62c8ef")
        ctk.CTkLabel(
            frame,
            text="Use a public YouTube URL or choose a local video file. Uploaded files are sent directly to Gemini and are not copied into the database.",
            font=FONT_SMALL,
            text_color="#969bb1",
            wraplength=1000,
            justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 10))

        url_row = ctk.CTkFrame(frame, fg_color="transparent")
        url_row.pack(fill="x", padx=18, pady=4)
        ctk.CTkLabel(url_row, text="YouTube URL", width=110, anchor="w", font=FONT_BODY).pack(side="left")
        self.url_entry = ctk.CTkEntry(url_row, placeholder_text="https://www.youtube.com/watch?v=...", height=34)
        self.url_entry.pack(side="left", fill="x", expand=True)
        self.url_entry.insert(0, "https://www.youtube.com/watch?v=pJ1TSCWc44Y")

        file_row = ctk.CTkFrame(frame, fg_color="transparent")
        file_row.pack(fill="x", padx=18, pady=4)
        ctk.CTkButton(file_row, text="Choose Video File", width=150, height=34, command=self.choose_video).pack(side="left")
        self.file_label = ctk.CTkLabel(file_row, text="No local file selected", font=FONT_SMALL, text_color="#858a9e")
        self.file_label.pack(side="left", padx=10)
        ctk.CTkButton(
            file_row,
            text="Clear",
            width=65,
            height=28,
            command=self.clear_video,
            fg_color="#292c40",
            hover_color="#3a3f5b",
        ).pack(side="right")

        self.analyze_button = ctk.CTkButton(
            frame,
            text="Analyze Video",
            height=42,
            command=self.start_analysis,
            fg_color="#376f9f",
            hover_color="#478cc2",
            font=FONT_BODY,
        )
        self.analyze_button.pack(fill="x", padx=18, pady=(12, 6))
        self.status_label = ctk.CTkLabel(frame, text="Ready", font=FONT_SMALL, text_color="#a4a8ba")
        self.status_label.pack(pady=(0, 14))

    def choose_video(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose a video",
            filetypes=[("Video files", "*.mp4 *.mov *.avi *.mkv *.webm *.wmv"), ("All files", "*.*")],
        )
        if path:
            self.current_video_path = path
            self.file_label.configure(text=Path(path).name)

    def clear_video(self) -> None:
        self.current_video_path = None
        self.file_label.configure(text="No local file selected")

    def start_analysis(self) -> None:
        if not self.keys:
            messagebox.showwarning("API key required", "Add at least one Gemini API key before analyzing.")
            return
        url = self.url_entry.get().strip()
        source = self.current_video_path or url
        if not source:
            messagebox.showwarning("Video required", "Enter a YouTube URL or choose a video file.")
            return
        prompt = self.prompt_box.get("1.0", "end").strip()
        keys = [item["key_text"] for item in self.keys]
        self.analyze_button.configure(state="disabled")
        threading.Thread(target=self._analysis_worker, args=(source, url, prompt, keys), daemon=True).start()

    def _analysis_worker(self, source: str, url: str, prompt: str, keys: list[str]) -> None:
        self.set_status("Analyzing with Gemini. This can take several minutes...")
        try:
            result = VideoAnalyzer(keys, prompt).analyze_video(source)
            display_source = url or f"uploaded_file: {Path(source).name}"
            if result.get("status") != "success":
                raise RuntimeError(result.get("message", "Gemini returned no analysis"))
            with connect_db() as connection:
                connection.execute(
                    "INSERT INTO video_analyses (youtube_url, status, analysis_result, active_api_key_suffix, prompt_text_used, created_at, completed_at) VALUES (?, 'completed', ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
                    (
                        display_source,
                        result.get("analysis_text", ""),
                        result.get("active_key_used_suffix"),
                        prompt,
                    ),
                )
                suffix = result.get("active_key_used_suffix")
                if suffix:
                    connection.execute(
                        "UPDATE api_keys SET usage_count = usage_count + 1 WHERE substr(key_text, -8) = ?",
                        (suffix,),
                    )
            self.set_status("Analysis complete.")
            self.show_info_async("Analysis complete", "The full analysis has been saved and is shown below.")
        except Exception as error:
            self.set_status(f"Analysis failed: {error}")
            self.show_error_async("Analysis failed", str(error))
        finally:
            self.after(0, lambda: self.analyze_button.configure(state="normal"))
            self.refresh_all()

    # ---------------- Results and conversion ----------------
    def build_results_section(self) -> None:
        frame = self.section("Analysis Details & Converted Prompts", "#ef79b3")
        self.results_list = ctk.CTkFrame(frame, fg_color="#10111d", corner_radius=10)
        self.results_list.pack(fill="x", padx=18, pady=(0, 16))

    def render_results(self) -> None:
        for child in self.results_list.winfo_children():
            child.destroy()
        if not self.analyses:
            ctk.CTkLabel(self.results_list, text="No analyses yet.", font=FONT_BODY, text_color="#777c91").pack(pady=28)
            return

        for item in self.analyses:
            card = ctk.CTkFrame(self.results_list, fg_color="#191b2d", corner_radius=10)
            card.pack(fill="x", padx=8, pady=7)
            header = ctk.CTkFrame(card, fg_color="transparent")
            header.pack(fill="x", padx=12, pady=(10, 4))
            ctk.CTkLabel(
                header,
                text=item["youtube_url"],
                font=FONT_BODY,
                text_color="#61c9ef",
                anchor="w",
            ).pack(side="left", fill="x", expand=True)
            status = item["status"].upper()
            ctk.CTkLabel(header, text=status, font=FONT_SMALL, text_color="#70ed92" if status == "COMPLETED" else "#f2c45e").pack(side="right")

            ctk.CTkLabel(card, text="Analysis Details", font=FONT_BODY, text_color="#f6c85f", anchor="w").pack(anchor="w", padx=12, pady=(6, 3))
            details = ctk.CTkTextbox(card, height=170, font=FONT_MONO, wrap="word", fg_color="#0f101a")
            details.insert("1.0", item.get("analysis_result") or item.get("error_message") or "No result yet.")
            details.configure(state="disabled")
            details.pack(fill="x", padx=12, pady=(0, 8))

            button = ctk.CTkButton(
                card,
                text="Convert to Image / Video Prompts",
                height=34,
                command=lambda analysis_id=item["id"]: self.start_conversion(analysis_id),
                fg_color="#6e48a2",
                hover_color="#895fc0",
            )
            button.pack(anchor="w", padx=12, pady=(0, 8))

            if item.get("converted_prompts"):
                ctk.CTkLabel(card, text="Converted Prompts", font=FONT_BODY, text_color="#ef79b3", anchor="w").pack(anchor="w", padx=12, pady=(2, 3))
                converted = ctk.CTkTextbox(card, height=210, font=FONT_MONO, wrap="word", fg_color="#111225")
                converted.insert("1.0", item["converted_prompts"])
                converted.configure(state="disabled")
                converted.pack(fill="x", padx=12, pady=(0, 12))

    def start_conversion(self, analysis_id: int) -> None:
        if not self.keys:
            messagebox.showwarning("API key required", "Add at least one Gemini API key first.")
            return
        keys = [item["key_text"] for item in self.keys]
        threading.Thread(target=self._conversion_worker, args=(analysis_id, keys), daemon=True).start()

    def _conversion_worker(self, analysis_id: int, keys: list[str]) -> None:
        self.set_status(f"Converting analysis #{analysis_id} into matched prompts...")
        try:
            with connect_db() as connection:
                record = connection.execute("SELECT analysis_result FROM video_analyses WHERE id = ?", (analysis_id,)).fetchone()
            if not record or not record["analysis_result"]:
                raise RuntimeError("This analysis has no text to convert.")
            converted = PromptConverter(keys).convert(record["analysis_result"])
            with connect_db() as connection:
                connection.execute(
                    "UPDATE video_analyses SET converted_prompts = ?, status = 'completed' WHERE id = ?",
                    (converted, analysis_id),
                )
            self.set_status("Prompt conversion complete.")
            self.show_info_async("Conversion complete", "Matched image and video prompts are now displayed below the analysis.")
        except Exception as error:
            self.set_status(f"Conversion failed: {error}")
            self.show_error_async("Conversion failed", str(error))
        finally:
            self.refresh_all()

    # ---------------- Refresh / UI helpers ----------------
    def refresh_all(self) -> None:
        threading.Thread(target=self._refresh_worker, daemon=True).start()

    def _refresh_worker(self) -> None:
        try:
            with connect_db() as connection:
                keys = connection.execute(
                    "SELECT id, key_text, label, usage_count FROM api_keys WHERE is_active = 1 ORDER BY id DESC"
                ).fetchall()
                prompt = connection.execute(
                    "SELECT prompt_text FROM analysis_prompts WHERE is_active = 1 ORDER BY id DESC LIMIT 1"
                ).fetchone()
                analyses = connection.execute(
                    "SELECT id, youtube_url, status, analysis_result, active_api_key_suffix, prompt_text_used, error_message, converted_prompts, created_at FROM video_analyses ORDER BY id DESC LIMIT 10"
                ).fetchall()
            self.keys = [dict(row) for row in keys]
            self.active_prompt = prompt["prompt_text"] if prompt else DEFAULT_PROMPT
            self.analyses = [dict(row) for row in analyses]
            self.after(0, self.update_ui)
        except Exception as error:
            self.set_status(f"Database refresh failed: {error}")

    def update_ui(self) -> None:
        if self.prompt_box.cget("state") == "disabled":
            self.prompt_box.configure(state="normal")
            self.prompt_box.delete("1.0", "end")
            self.prompt_box.insert("1.0", self.active_prompt)
            self.prompt_box.configure(state="disabled")
        self.render_keys()
        self.render_results()

    def set_status(self, text: str) -> None:
        self.after(0, lambda: self.status_label.configure(text=text))

    def show_info_async(self, title: str, message: str) -> None:
        self.after(0, lambda: messagebox.showinfo(title, message))

    def show_error_async(self, title: str, message: str) -> None:
        self.after(0, lambda: messagebox.showerror(title, message))


if __name__ == "__main__":
    app = VideoAnalystApp()
    app.mainloop()
