# Video Analyst — Windows Installer

The previous project download did not contain an `installer.exe` because the development sandbox is Linux. PyInstaller does not cross-compile a native Windows executable from Linux, and the old Python helper only created an executable after being run.

This folder now contains the complete Windows packaging setup.

## Fastest option: build on Windows

1. Install **Python 3.11+** from https://www.python.org/downloads/windows/
2. Install **Inno Setup 6** from https://jrsoftware.org/isinfo.php
3. Open this project folder in Windows Explorer.
4. Double-click:

```text
windows_app\build_windows.bat
```

The installer will be created here:

```text
windows_app\installer_output\VideoAnalyst-Installer.exe
```

You can then double-click that file to install the app like a normal Windows application.

## Build through GitHub Actions

If you do not have a Windows computer:

1. Upload/push this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Windows Installer**.
4. Click **Run workflow**.
5. When it finishes, download the artifact named **VideoAnalyst-Windows-Installer**.
6. Inside it is `VideoAnalyst-Installer.exe`.

The workflow uses a Windows runner, builds `VideoAnalyst.exe` with PyInstaller, compiles it with Inno Setup, and uploads the installer.

## What the installer includes

- Native Windows desktop interface
- Gemini analysis engine
- Image/video prompt conversion engine
- CustomTkinter UI and Python runtime
- Local SQLite database stored at `%LOCALAPPDATA%\VideoAnalyst\video_analyst.sqlite3`

PostgreSQL is **not required** for the installed Windows app. Add your Gemini API keys inside the app after installation. Keys, prompts, analysis details, and converted prompts are stored locally on that computer.

## Important notes

- The generated installer is named `VideoAnalyst-Installer.exe`, not merely `installer.exe`.
- The build must be performed on Windows or through the included GitHub Actions workflow.
- Never commit or share a copy of the app database after adding API keys.
