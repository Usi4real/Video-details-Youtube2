# PyInstaller specification for the standalone Windows desktop app.
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_submodules

project_root = Path(SPECPATH).parent.parent

# Include the local analysis engine as importable bundled Python modules.
datas = [(str(project_root / "python_app"), "python_app")]
binaries = []
hiddenimports = collect_submodules("python_app")

# Gemini and CustomTkinter use package data and dynamic imports.
for package in ("customtkinter", "google.generativeai", "google.ai.generativelanguage"):
    try:
        package_datas, package_binaries, package_hidden = collect_all(package)
        datas.extend(package_datas)
        binaries.extend(package_binaries)
        hiddenimports.extend(package_hidden)
    except Exception:
        hiddenimports.extend(collect_submodules(package))

analysis = Analysis(
    [str(project_root / "windows_app" / "app.py")],
    pathex=[str(project_root)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter.test"],
    noarchive=False,
)

pyz = PYZ(analysis.pure)

executable = EXE(
    pyz,
    analysis.scripts,
    analysis.binaries,
    analysis.datas,
    [],
    name="VideoAnalyst",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
)
