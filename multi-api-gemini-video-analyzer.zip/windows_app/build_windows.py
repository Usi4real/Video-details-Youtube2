#!/usr/bin/env python3
"""Build helper for Video Analyst.

A real Windows .exe must be built on Windows because PyInstaller does not
cross-compile Windows executables from Linux/macOS. Run build_windows.bat on
a Windows machine, or use the included GitHub Actions workflow.
"""
from __future__ import annotations

import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

if platform.system() != "Windows":
    print("This project is currently running on a non-Windows host.")
    print("PyInstaller cannot cross-compile a native Windows .exe here.")
    print("Use one of these options:")
    print("  1. On Windows, double-click windows_app\\build_windows.bat")
    print("  2. Push this project to GitHub and run the Build Windows Installer workflow")
    sys.exit(0)

bat_file = ROOT / "windows_app" / "build_windows.bat"
subprocess.run(["cmd", "/c", str(bat_file)], check=True)
